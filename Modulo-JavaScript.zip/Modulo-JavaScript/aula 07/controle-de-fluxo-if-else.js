const prompt = require("readline-sync")

const idade = Number(prompt.question("Qual eh a sua idade"))
// Estrutura condicional: if/else

if (idade >= 18) {
  console.log("voce eh maior de idade!")
} else {
  console.log("voce eh menor de idade")
}

const mediaDoAluno = 4

// Media >= 7 => Aprovado
// Media < 7 e Media >= 5 => Prova final
// Media < 5 => Reprovado

if (mediaDoAluno >= 7) {
  console.log("Aprovado")
} else if (mediaDoAluno < 7 && mediaDoAluno >= 5) {
  console.log("Prova final")
} else {
  console.log("Reprovado")
}

const idadeDirigir = 18
const temCNH = true

if (idadeDirigir >= 18 && temCNH) {
  console.log("parabens, voce pode dirigir")
} else {
  console.log("voce não pode dirigir")
}
