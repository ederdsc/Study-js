
// Muito util quando a variavel possui valores especificos

const permissoes = "aluno" // 'aluno' ou 'professor' ou 'admin'

switch(permissoes) {
  case "aluno":
    console.log('Voce pode vizualizar as aulas')
    break
  case "professor":
    console.log('voce pode editar as aulas e acrescentar exercicios')
    break
  case "admin":
    console.log('voce tem todas as permissoes no sistema')
    break
    default:
      console.log('não reconhecido no sistema')
}