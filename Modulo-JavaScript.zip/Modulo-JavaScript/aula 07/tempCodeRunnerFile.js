const numero = 37

numero >= 37 ? console.log('correto') : console.log('errado')