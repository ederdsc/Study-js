// Utilize sempre o camel case
var nomeDoProfessor = "ÉDER CAMARGO" // string (texto) utilize sempre aspas
var idade = 27 // number
var altura = 1.77 // number
var estudando = true // boolean (booleano: verdadeiro ou falso)

console.log(nomeDoProfessor)
console.log(typeof nomeDoProfessor)
console.log(typeof idade)
// console.log (altura)
console.log(typeof estudando, typeof idade)

var semConteudo // declaração de variavel sem conteudo especificado

console.log(semConteudo)

var curso = "fronte end em react",
  topico = "javascript basico"

console.log(curso, topico)

// - Para criar variáveis no JavaScript devemos utilizar o `let` ou `const`.
// - Diferenças entre let e const
//     - let - permite que alteremos o valor/texto da variável.
//     - const - const vem da palavra constante, ou seja, valor fixo.


let notaDoAluno = 10
const mediaDoAluno = 8

notaDoAluno = 15  - // <- exemplo de mudança da variavel let
// ! mediaDoAluno = 5; Não é permitido !!! <- segue exemplo de como não é possivel realizar a mudança da variavel const, se não obtemos um erro.

console.log(notaDoAluno)
console.log(mediaDoAluno)
