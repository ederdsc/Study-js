const nota1 = 10
const nota2 = 8

const somaDasNotas = nota1 + nota2

console.log("soma das notas =", somaDasNotas)

const nota3 = 10
const nota4 = 8
const somaDasNotas1 = nota3 + nota4
let mediaDasNotas = somaDasNotas1 / 2

console.log("media das notas = ", mediaDasNotas)

const subtracaoDasNotas1 = nota3 - nota4

console.log("subtração das notas = ", subtracaoDasNotas1)

let multiplicacaoDasNotas = nota3 * nota4 
console.log('multiplicação das notas =', multiplicacaoDasNotas)

const aluno1 = 10
const aluno2 = 8

let mediaDosAlunos = (aluno1 + aluno2) / 2

console.log("media dos alunos = ", mediaDosAlunos)

console.log("hello world")