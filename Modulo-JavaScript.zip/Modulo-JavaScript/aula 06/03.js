const prompt = require("readline-sync")

const idade = prompt.question("qual eh sua idade?")

const idadeNumber = Number(idade)

console.log(idadeNumber, typeof idadeNumber)

// Coerção implicita
