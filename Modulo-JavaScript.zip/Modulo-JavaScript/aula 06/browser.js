
const idade = window.prompt('qual é sua idade')

console.log('o usuario tem', idade, 'anos de idade')