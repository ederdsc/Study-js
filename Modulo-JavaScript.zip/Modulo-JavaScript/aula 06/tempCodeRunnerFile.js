console.log(Number('X')); // NaN Not a number
console.log(String(10), typeof String(10));
console.log(Boolean(0));