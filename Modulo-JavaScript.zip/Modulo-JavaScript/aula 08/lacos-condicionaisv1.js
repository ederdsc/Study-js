const prompt = require("readline-sync")

let saldo = Number (prompt.question("Qual eh o seu saldo? "))

while (saldo < 0) {
  saldo = Number (prompt.question("Saldo invalido! Informe novamente"))
}

console.log("seu saldo é: ", saldo)